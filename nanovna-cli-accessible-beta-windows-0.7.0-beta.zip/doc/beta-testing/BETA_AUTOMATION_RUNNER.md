# Beta Automation Runner

Dieses Tool ist für interaktive Test-Sessions mit Chat-Begleitung gedacht.
Ich kann es hier steuern, während du mir Live-Beobachtungen schreibst.

## Datei

- tools/beta_runner.ps1
- tools/beta_runner.py (optional, falls Python vorhanden)

## Start

Windows PowerShell:

- .\tools\beta_runner.ps1 init
- .\tools\beta_runner.ps1 start --name "Beta Session mit NanoVNA"
- .\tools\beta_runner.ps1 status

Wenn Python vorhanden ist, geht alternativ:

- py -3 tools/beta_runner.py init

## Während des Tests

Du schreibst im Chat, was passiert. Ich trage es ein mit:

- .\tools\beta_runner.ps1 note --scenario s1 --kind pass --text "COM Port erkannt"
- .\tools\beta_runner.ps1 note --scenario s3 --kind issue --text "Audio knackt bei hoher Lautstärke"

Zwischenstände erfassen:

- .\tools\beta_runner.ps1 snapshot --label "nach s3"

Logs prüfen:

- .\tools\beta_runner.ps1 scan-logs --last 5

Export-Dateien prüfen:

- .\tools\beta_runner.ps1 check-exports

## Session beenden und Report

- .\tools\beta_runner.ps1 finish --status partial
- .\tools\beta_runner.ps1 report

Der Report landet in:

- .beta_runner/sessions/<session-id>.md

## Szenario-Codes

- s1 = First-Time User Setup
- s2 = Antenna Analysis
- s3 = Acoustic Analysis Basic
- s4 = Acoustic Analysis Advanced
- s5 = Continuous Sweep
- s6 = Export and Import
- s7 = Braille Export
- s8 = Screen Reader Compatibility
- s9 = Calibration
- s10 = Stress Testing
- s11 = Web Interface Cross-Platform
