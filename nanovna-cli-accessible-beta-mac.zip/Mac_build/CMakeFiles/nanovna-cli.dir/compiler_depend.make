# Empty compiler generated dependencies file for nanovna-cli.
# This may be replaced when dependencies are built.
