
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/user/nanovna-cli-accessible-cpa/src/acoustic_analyzer.cpp" "CMakeFiles/nanovna-cli.dir/src/acoustic_analyzer.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/acoustic_analyzer.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/audio.cpp" "CMakeFiles/nanovna-cli.dir/src/audio.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/audio.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/braille_printer.cpp" "CMakeFiles/nanovna-cli.dir/src/braille_printer.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/braille_printer.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/comfort_functions.cpp" "CMakeFiles/nanovna-cli.dir/src/comfort_functions.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/comfort_functions.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/comfort_menu.cpp" "CMakeFiles/nanovna-cli.dir/src/comfort_menu.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/comfort_menu.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/comfort_menu_extra.cpp" "CMakeFiles/nanovna-cli.dir/src/comfort_menu_extra.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/comfort_menu_extra.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/comm_serial.cpp" "CMakeFiles/nanovna-cli.dir/src/comm_serial.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/comm_serial.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/export.cpp" "CMakeFiles/nanovna-cli.dir/src/export.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/export.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/help.cpp" "CMakeFiles/nanovna-cli.dir/src/help.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/help.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/import.cpp" "CMakeFiles/nanovna-cli.dir/src/import.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/import.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/logger.cpp" "CMakeFiles/nanovna-cli.dir/src/logger.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/logger.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/main.cpp" "CMakeFiles/nanovna-cli.dir/src/main.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/main.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/math_logger.cpp" "CMakeFiles/nanovna-cli.dir/src/math_logger.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/math_logger.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/measurement.cpp" "CMakeFiles/nanovna-cli.dir/src/measurement.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/measurement.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/midi_engine.cpp" "CMakeFiles/nanovna-cli.dir/src/midi_engine.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/midi_engine.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/platform/macos/audio_backend_portaudio.cpp" "CMakeFiles/nanovna-cli.dir/src/platform/macos/audio_backend_portaudio.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/platform/macos/audio_backend_portaudio.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/platform/macos/midi_platform_macos.cpp" "CMakeFiles/nanovna-cli.dir/src/platform/macos/midi_platform_macos.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/platform/macos/midi_platform_macos.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/platform/posix/console_input_posix.cpp" "CMakeFiles/nanovna-cli.dir/src/platform/posix/console_input_posix.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/platform/posix/console_input_posix.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/protocol.cpp" "CMakeFiles/nanovna-cli.dir/src/protocol.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/protocol.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/raw_math.cpp" "CMakeFiles/nanovna-cli.dir/src/raw_math.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/raw_math.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/settings.cpp" "CMakeFiles/nanovna-cli.dir/src/settings.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/settings.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/smith_visualizer.cpp" "CMakeFiles/nanovna-cli.dir/src/smith_visualizer.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/smith_visualizer.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/spatial_audio_wizard.cpp" "CMakeFiles/nanovna-cli.dir/src/spatial_audio_wizard.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/spatial_audio_wizard.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/synthesizer_engine.cpp" "CMakeFiles/nanovna-cli.dir/src/synthesizer_engine.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/synthesizer_engine.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/translation.cpp" "CMakeFiles/nanovna-cli.dir/src/translation.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/translation.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/ui.cpp" "CMakeFiles/nanovna-cli.dir/src/ui.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/ui.cpp.o.d"
  "/Users/user/nanovna-cli-accessible-cpa/src/web_server.cpp" "CMakeFiles/nanovna-cli.dir/src/web_server.cpp.o" "gcc" "CMakeFiles/nanovna-cli.dir/src/web_server.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
